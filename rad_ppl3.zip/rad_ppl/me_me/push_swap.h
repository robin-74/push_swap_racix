#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

#include <stdlib.h>
# include "libft/libft.h"
# include "ft_printf/ft_printf.h"

typedef struct s_node
{
	int				val;
	int				index;
	struct s_node	*next;
}				t_node;

/* init.c */
void	init_sa(t_node **s, int ac, char **argv);

/* push.c */
void	push(t_node **source, t_node **dest);
void	pa(t_node **sb, t_node **sa);
void	pb(t_node **sa, t_node **sb);

/* radix_sort.c */
void	radix_sort(t_node **stack_a, t_node **stack_b);

/* rotate.c */
void	rotate(t_node **s);
void	ra(t_node **s);
void	rb(t_node **s);
void	rr(t_node **sa, t_node **sb);

/* sort.c */
void	sort_three(t_node **s);
void	sort_four(t_node **sa, t_node **sb);
void	sort_five(t_node **sa, t_node **sb);
void	sort_stack(t_node **sa, t_node **sb);

/* swap.c */
void	swap(t_node **s);
void	sa(t_node **sa);
void	sb(t_node **sb);
void	ss(t_node **sa, t_node **sb);

/* utils.c */
t_node	*create_node(int val);
int		stack_size(t_node *s);
 // Ensure function consistency
t_node	*ft_get_last_node(t_node *s);
int		ft_get_distance_to_node(t_node **s, int index);
int		ft_is_stack_sorted(t_node **s);
void	ft_add_node_to_front(t_node **s, t_node *new);
void	ft_add_index_to_stack(t_node **s);
void	ft_free_str(char **str);
void	sort_small(t_node **sa, t_node **sb);
/* checker.c */
int		issorted(t_node **s);

/* error.c */
void	free_all(t_node **stack);
void	rrb(t_node **stack_a);
void	rra(t_node **stack_a);
#endif
