#include "push_swap.h"
int	min_index(t_node **s,int z)
{
	t_node	*head;
	int		ans;

	head = *s;
	ans = head->index;
	while (head->next)
	{
		head = head->next;
		if ((head->index < ans) && head->index != z)
			ans = head->index;
	}
	return (ans);
}
int	get_dist_to_min(t_node **stack, int index)
{
	t_node	*head;
	int		ans;

	ans = 0;
	head = *stack;
	while (head)
	{
		if (head->index == index)
			break ;
		ans++;
		head = head->next;
	}
	return (ans);
}
void	sort_small(t_node **s, t_node **sb)
{
	int	size;

	size = stack_size(*s);
	    if (size == 2)
			sa(s);
		else if (size == 3)
			sort_three(s);
		else if (size == 4)
			sort_four(s, sb);
}
void	sort_three(t_node **s)
{
	if ((*s)->index == min_index(s, -1) && (*s)->next->index
		> (*s)->next->next->index)
	{
		ra(s);
		sa(s);
		rra(s);
	}
	else if ((*s)->index
		== min_index(s, min_index(s, -1)))
	{
		if ((*s)->next->index < (*s)->index)
			sa(s);
		else
			rra(s);
	}
	else
	{
		if ((*s)->next->index == min_index(s, -1))
			ra(s);
		else
		{
			sa(s);
			rra(s);
		}
	}
}
void	sort_four(t_node **sa, t_node **sb)
{
	int	distance;
    int min;

    min = min_index(sa,-1);
	distance = get_dist_to_min(sa, min);
	if (distance == 1)
		ra(sa);
	else if (distance == 2)
	{
		ra(sa);
		ra(sa);
	}
	else if (distance == 3)
		rra(sa);
	if (!issorted(sa))
	{
		pb(sa, sb);
		sort_three(sa);
		pa(sb, sa);
	}
}