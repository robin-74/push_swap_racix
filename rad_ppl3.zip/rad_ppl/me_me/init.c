#include "push_swap.h"
t_node	*ft_get_next_min(t_node **stack)
{
	t_node	*head;
	t_node	*min;
	int		has_min;

	min = NULL;
	has_min = 0;
	head = *stack;
	if (head)
	{
		while (head)
		{
			if ((head->index == -1) && (!has_min || head->val
					< min->val))
			{
				min = head;
				has_min = 1;
			}
			head = head->next;
		}
	}
	return (min);
}
void	push_back(t_node **stack, t_node *new_node)
{
	t_node	*tmp;

	if (!new_node)
		return ;
	if (*stack)
	{
		tmp = ft_get_last_node(*stack);
		tmp -> next = new_node;
	}
	else
		*stack = new_node;
}

void	create_index(t_node **stack)
{
	t_node	*head;
	int		index;

	index = 0;
	head = ft_get_next_min(stack);
	while (head)
	{
		head->index = index++;
		head = ft_get_next_min(stack);
	}
}

void	init_sa(t_node **s, int ac, char **argv)
{
	t_node	*new;
	int		i;
    int temp;

	i = 0;
	if (ac == 2)
		argv = ft_split(argv[1], ' ');
	else
		i++;
	while (argv[i])
	{
        temp = ft_atoi(argv[i]);
		new = create_node(temp);
		push_back(s, new);
		i++;
	}
	create_index(s);
	if (ac == 2)
		ft_free_str(argv);
}
