#include "push_swap.h"

int	issorted(t_node **s)
{
	t_node	*temp;

	temp = *s;
	while (temp->next)
	{
		if (temp->val > temp->next->val)
			return (0);
		temp = temp->next;
	}
	return (3);
}