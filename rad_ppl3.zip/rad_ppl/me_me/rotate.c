#include "push_swap.h"
void	rotate(t_node **s)
{
	t_node	*tail;
	t_node	*head;

	if (stack_size(*s) > 2)
	{
		tail = ft_get_last_node(*s);
		head = *s;
		*s = (*s)->next;
		tail->next = head;
		head->next = NULL;
	}
}

void	ra(t_node **s)
{
	rotate(s);
	ft_printf("\nra");
}

void	rb(t_node **s)
{
	rotate(s);
	ft_printf("\nrb");
}

void	rr(t_node **sa, t_node **sb)
{
	rotate(sa);
	rotate(sb);
	ft_printf("\nrrr");
}
