#include "push_swap.h"

void	swap(t_node **s)
{
	t_node	*tmp;
    if (stack_size(*s) > 2)
        return ;
	
	tmp = (*s)->next;
	(*s)->next = tmp->next;
	tmp->next = *s;
	s = tmp;
}
void	sa(t_node **sa)
{
	swap(sa);
	ft_printf("%s", "sa");
}

void	sb(t_node **sb)
{
	swap(sb);
	ft_printf("%s", "sb");
}

void	ss(t_node **sa, t_node **sb)
{
	swap(sa);
	swap(sb);
	ft_printf("%s", "ss");
}
