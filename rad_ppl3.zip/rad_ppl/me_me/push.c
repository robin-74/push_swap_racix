#include "push_swap.h"

void	push_front(t_node **stack, t_node *new_node)
{
	if (!new_node)
		return ;
	new_node -> next = *stack;
	*stack = new_node;
}
void	push(t_node **source, t_node **dest)
{
	t_node	*tmp;

	if (stack_size(*source) != 0)
	{
		tmp = *source;
		*source = (*source)->next;
		push_front(dest, tmp);
	}
}

void	pa(t_node **sb, t_node **sa)
{
	push(sb, sa);
	ft_printf("pa");
}

void	pb(t_node **sa, t_node **sb)
{
	push(sa, sb);
	ft_printf("pb");
}