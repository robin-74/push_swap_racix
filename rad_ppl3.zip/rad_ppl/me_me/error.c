#include "push_swap.h"

void	free_all(t_node **stack)
{
	t_node	*head;
	t_node	*tmp;

	head = *stack;
	while (head)
	{
		tmp = head;
		head = head ->next;
		free(tmp);
	}
	free(stack);
}