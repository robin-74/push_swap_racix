#include "push_swap.h"

void	radix_sort(t_node **sa, t_node **sb)
{
	int		i;
	int		j;
	int		size;

	i = 0;
	size = stack_size(*sa);
	while (!issorted(sa))
	{
		j = 0;
		while (j++ < size)
		{
			if ((((*sa)->index >> i) & 1) == 1)
				ra(sa);
			else
				pb(sa, sb);
		}
		while (issorted(sb) != 0)
			pa(sb, sa);
		i++;
	}
}