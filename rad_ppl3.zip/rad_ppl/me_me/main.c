#include "push_swap.h"

void printer(int *s)
{
    int i =0 ; 
    while(s[i])
    {
        ft_printf("%d",s[i]);
        i++;
    };
}
void done(char *s, int n)
{
    ft_printf("%s",s);
    exit(n);
}
int	main(int argc, char **argv)
{
	t_node	**sa;
	t_node	**sb;

	if (argc < 2)
		return (0);
	//check_arg(argc, argv);
	sa = malloc(sizeof(t_node *));
	sb = malloc(sizeof(t_node *));
	*sa = NULL;
	*sb = NULL;
	init_sa(sa, argc, argv);

	if (issorted(sa) == 3)
	{
		free_all(sa);
		free_all(sb);
		done("sorted, Done!",1);
	}
	if (stack_size(*sa)<= 4)
        sort_small(sa,sb);
    else
    {
        radix_sort(sa,sb);
    }
    
	free_all(sa);
	free_all(sb);
	return (0);
}
