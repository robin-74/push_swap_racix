#include "push_swap.h"

t_node	*create_node(int val)
{
	t_node	*ans;

	ans = malloc(sizeof(t_node));
	if (!ans)
		return (NULL);
	ans->val = val;
	ans->index = -1;
	ans->next = NULL;
	return (ans);
}

int stack_size(t_node *s)
{
    int i ;
    i = 0;
    while(s)
    {
        i++;
        s= s->next;
    };
    return (i);
}